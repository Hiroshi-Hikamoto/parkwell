export const environment = {
  production: true,
  ws: 'https://thecocktaildb.com/api/json/v1/1/',
  firebaseConfig: {
    apiKey: "AIzaSyAmGQ0Mqsnb-lpHBd2BGSCag1a3KlLy6tE",
    authDomain: "movie-dec-12.firebaseapp.com",
    projectId: "movie-dec-12",
    storageBucket: "movie-dec-12.appspot.com",
    messagingSenderId: "440115681291",
    appId: "1:440115681291:web:b1f0dd6055c9f0a8dfcf0e",
    measurementId: "G-JDJKRFEMZG"
  }
};
