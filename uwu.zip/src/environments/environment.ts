export const environment = {
  production: false,
  ws: 'https://thecocktaildb.com/api/json/v1/1/',
  firebaseConfig: {
    apiKey: "AIzaSyBfMeUzXjyNZG7IDMK_RpAQF6rTN_33naI",
    authDomain: "movie-dic-12.firebaseapp.com",
    projectId: "movie-dic-12",
    storageBucket: "movie-dic-12.appspot.com",
    messagingSenderId: "778994299449",
    appId: "1:778994299449:web:0c3f26a5f1ec34293453e8"
  }
};